import { useState, useRef, useEffect } from 'react';
import { Send, Bot, Sparkles, MessageSquare, Trash2, ShieldCheck, Info, FileSpreadsheet, FileText } from 'lucide-react';
import Markdown from 'react-markdown';
import * as XLSX from 'xlsx';
import { format } from 'date-fns';
import { id } from 'date-fns/locale';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

interface FinBOTChatProps {
  profile: any;
  transactions: any[];
}

export default function FinBOTChat({ profile, transactions }: FinBOTChatProps) {
  const currency = profile?.currency || 'Rp';
  const displayUserName = profile?.displayName || 'Teman AturDuit';

  const exportAllXLSX = () => {
    if (!transactions || transactions.length === 0) {
      alert('Tidak ada data transaksi untuk diekspor.');
      return;
    }
    const data = transactions.map((t, idx) => {
      const typeLabel = t.type === 'income' ? 'Pemasukan' : t.type === 'expense' ? 'Pengeluaran' : 'Tabungan Goal';
      return {
        'No': idx + 1,
        'Tanggal': t.date,
        'Tipe': typeLabel,
        'Kategori': t.category || '',
        'Keterangan': t.description || '',
        [`Jumlah (${currency})`]: t.amount
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(data);

    worksheet['!cols'] = [
      { wch: 6 },  // No
      { wch: 15 }, // Tanggal
      { wch: 15 }, // Tipe
      { wch: 15 }, // Kategori
      { wch: 30 }, // Keterangan
      { wch: 18 }  // Jumlah
    ];

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Semua Transaksi');

    const dateStr = format(new Date(), 'yyyyMMdd');
    XLSX.writeFile(workbook, `Laporan_FinBOT_AturDuit_${dateStr}.xlsx`);
  };

  const exportAllPDF = () => {
    if (!transactions || transactions.length === 0) {
      alert('Tidak ada data transaksi untuk diekspor.');
      return;
    }
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Gagal membuka halaman baru. Harap izinkan pop-up untuk mencetak laporan.');
      return;
    }

    const dateStr = format(new Date(), 'd MMMM yyyy HH:mm', { locale: id });

    // Calculate metrics for charts & summary boxes
    const incomeTxns = transactions.filter(t => t.type === 'income');
    const expenseTxns = transactions.filter(t => t.type === 'expense');
    const totalIncome = incomeTxns.reduce((sum, t) => sum + (t.amount || 0), 0);
    const totalExpense = expenseTxns.reduce((sum, t) => sum + (t.amount || 0), 0);
    const totalBalance = totalIncome - totalExpense;
    const grandTotal = totalIncome + totalExpense;

    const incomePercent = grandTotal > 0 ? Math.round((totalIncome / grandTotal) * 100) : 0;
    const expensePercent = grandTotal > 0 ? Math.round((totalExpense / grandTotal) * 100) : 0;

    const formatVal = (val: number) => {
      return `${currency} ${new Intl.NumberFormat('id-ID').format(val)}`;
    };

    // Group expenses by category
    const categoryMap: { [key: string]: number } = {};
    expenseTxns.forEach(t => {
      const cat = t.category || 'Lainnya';
      categoryMap[cat] = (categoryMap[cat] || 0) + (t.amount || 0);
    });

    const sortedCats = Object.entries(categoryMap)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3);

    const topCategoriesUI = sortedCats.length > 0
      ? sortedCats.map(([cat, amount]) => {
          const percentage = totalExpense > 0 ? Math.round((amount / totalExpense) * 100) : 0;
          const barColor = cat.toLowerCase().includes('food') ? '#f59e0b' :
                           cat.toLowerCase().includes('transport') ? '#3b82f6' :
                           cat.toLowerCase().includes('shopping') ? '#ec4899' :
                           cat.toLowerCase().includes('bill') || cat.toLowerCase().includes('home') ? '#8b5cf6' :
                           cat.toLowerCase().includes('entertainment') ? '#10b981' : '#6b7280';
          return `
            <div style="margin-bottom: 12px;">
              <div style="display: flex; justify-content: space-between; align-items: center; font-size: 11px; margin-bottom: 4px;">
                <span style="font-weight: 700; color: #374151;">${cat}</span>
                <span style="color: #6b7280; font-weight: 500;">${currency} ${new Intl.NumberFormat('id-ID').format(amount)} (${percentage}%)</span>
              </div>
              <div style="width: 100%; height: 6px; background-color: #f3f4f6; border-radius: 9999px; overflow: hidden;">
                <div style="width: ${percentage}%; height: 100%; background-color: ${barColor}; border-radius: 9999px;"></div>
              </div>
            </div>
          `;
        }).join('')
      : `<div style="text-align: center; color: #9ca3af; font-size: 11px; padding: 24px 0;">Belum ada data pengeluaran dicatat</div>`;

    const rows = transactions.map((t, idx) => {
      const typeLabel = t.type === 'income' ? 'Pemasukan' : t.type === 'expense' ? 'Pengeluaran' : 'Tabungan Goal';
      const amountFormatted = `${currency} ${new Intl.NumberFormat('id-ID').format(t.amount)}`;
      return `
        <tr style="border-bottom: 1px solid #f3f4f6;">
          <td style="padding: 12px; font-size: 11px; color: #374151;">${idx + 1}</td>
          <td style="padding: 12px; font-size: 11px; color: #374151;">${t.date}</td>
          <td style="padding: 12px; font-size: 11px; color: #374151; font-weight: 700;">${typeLabel}</td>
          <td style="padding: 12px; font-size: 11px; color: #374151;">${t.category}</td>
          <td style="padding: 12px; font-size: 11px; color: #374151;">${t.description || '-'}</td>
          <td style="padding: 12px; font-size: 11px; text-align: right; font-weight: 700; color: ${t.type === 'income' ? '#16a34a' : t.type === 'expense' ? '#dc2626' : '#2563eb'}">
            ${t.type === 'expense' ? '-' : t.type === 'income' ? '+' : ''}${amountFormatted}
          </td>
        </tr>
      `;
    }).join('');

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Laporan Transaksi AturDuit - FinBOT AI</title>
          <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
          <style>
            body {
              font-family: 'Plus Jakarta Sans', sans-serif;
              color: #111827;
              margin: 40px;
              background-color: #ffffff;
            }
            .header-container {
              display: flex;
              justify-content: space-between;
              align-items: center;
              border-bottom: 2px solid #111827;
              padding-bottom: 20px;
              margin-bottom: 30px;
            }
            .title-main {
              font-size: 22px;
              font-weight: 800;
              letter-spacing: -0.025em;
              text-transform: uppercase;
            }
            .subtitle-date {
              font-size: 12px;
              color: #4b5563;
              margin-top: 4px;
              font-weight: 500;
            }
            .meta-info {
              text-align: right;
              font-size: 11px;
              color: #4b5563;
              line-height: 1.5;
            }
            .summary-box {
              display: grid;
              grid-template-cols: repeat(3, 1fr);
              gap: 16px;
              margin-bottom: 24px;
            }
            .card-summary {
              background-color: #f9fafb;
              border: 1px solid #e5e7eb;
              padding: 14px 18px;
              border-radius: 16px;
            }
            .card-label {
              font-size: 9px;
              font-weight: 800;
              color: #6b7280;
              text-transform: uppercase;
              letter-spacing: 0.05em;
            }
            .card-amount {
              font-size: 16px;
              font-weight: 800;
              margin-top: 4px;
            }
            .charts-grid {
              display: grid;
              grid-template-cols: 1.2fr 1.8fr;
              gap: 20px;
              margin-bottom: 30px;
            }
            .chart-card {
              border: 1px solid #e5e7eb;
              border-radius: 20px;
              padding: 20px;
              background-color: #ffffff;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              margin-bottom: 40px;
            }
            th {
              background-color: #111827;
              color: white;
              text-align: left;
              padding: 12px;
              font-size: 10px;
              font-weight: 800;
              text-transform: uppercase;
              letter-spacing: 0.05em;
            }
            .print-btn-bar {
              text-align: center;
              margin-top: 40px;
              padding: 24px;
              background-color: #f3f4f6;
              border-radius: 20px;
              border: 1px dashed #d1d5db;
            }
            .btn-accent {
              background-color: #111827;
              color: white;
              border: none;
              padding: 10px 24px;
              font-size: 12px;
              font-weight: 800;
              border-radius: 12px;
              cursor: pointer;
              text-transform: uppercase;
              letter-spacing: 0.05em;
              margin-right: 10px;
              transition: background-color 0.2s;
            }
            .btn-accent:hover {
              background-color: #374151;
            }
            .btn-secondary {
              background-color: transparent;
              color: #4b5563;
              border: 1px solid #d1d5db;
              padding: 9px 24px;
              font-size: 12px;
              font-weight: 800;
              border-radius: 12px;
              cursor: pointer;
              text-transform: uppercase;
              letter-spacing: 0.05em;
            }
            @media print {
              .print-btn-bar { display: none; }
              body { margin: 20px; }
            }
          </style>
        </head>
        <body>
          <div class="header-container">
            <div>
              <div class="title-main">LAPORAN TRANSAKSI ATURDUIT</div>
              <div class="subtitle-date">Dokumen Ekspor Pintar - Direkomendasikan oleh FinBOT Advisor</div>
            </div>
            <div class="meta-info">
              <div>Pengguna: <b>${profile?.displayName || 'Teman AturDuit'}</b></div>
              <div>Mata Uang: <b>IDR (${currency})</b></div>
              <div>Tanggal Pembuatan: ${dateStr}</div>
            </div>
          </div>

          <div class="summary-box">
            <div class="card-summary" style="border-left: 4px solid #10b981;">
              <div class="card-label">Total Pemasukan</div>
              <div class="card-amount" style="color: #10b981;">${formatVal(totalIncome)}</div>
            </div>
            <div class="card-summary" style="border-left: 4px solid #ef4444;">
              <div class="card-label">Total Pengeluaran</div>
              <div class="card-amount" style="color: #ef4444;">${formatVal(totalExpense)}</div>
            </div>
            <div class="card-summary" style="border-left: 4px solid #3b82f6;">
              <div class="card-label">Sisa Saldo Kas</div>
              <div class="card-amount" style="color: #111827;">${formatVal(totalBalance)}</div>
            </div>
          </div>

          <!-- Bagian Grafik & Analisis Visual -->
          <div class="charts-grid">
            <div class="chart-card" style="display: flex; align-items: center; gap: 16px;">
              <div style="position: relative; width: 90px; height: 90px; flex-shrink: 0;">
                <svg width="90" height="90" viewBox="0 0 36 36">
                  <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                        fill="none" stroke="#f3f4f6" stroke-width="4" />
                  ${incomePercent > 0 ? `
                    <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                          fill="none" stroke="#10b981" stroke-width="4" stroke-dasharray="${incomePercent}, 100" />
                  ` : ''}
                  ${expensePercent > 0 ? `
                    <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                          fill="none" stroke="#ef4444" stroke-width="4" stroke-dasharray="${expensePercent}, 100" stroke-dashoffset="-${incomePercent}" />
                  ` : ''}
                </svg>
                <div style="position: absolute; top:0; left:0; right:0; bottom:0; display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center;">
                  <span style="font-size: 13px; font-weight: 800; color: #111827;">${incomePercent || 0}%</span>
                  <span style="font-size: 7px; color: #6b7280; font-weight: 800; text-transform: uppercase;">Masuk</span>
                </div>
              </div>
              <div style="flex-grow: 1;">
                <h4 style="margin: 0 0 8px 0; font-size: 10px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.05em; color: #6b7280;">Bauran Saldo</h4>
                <div style="display: flex; flex-direction: column; gap: 6px;">
                  <div style="display: flex; justify-content: space-between; align-items: center; font-size: 10px;">
                    <span style="display: flex; align-items: center; gap: 4px;"><span style="width: 6px; height: 6px; border-radius: 50%; background: #10b981; display: inline-block;"></span>Masuk</span>
                    <span style="font-weight: 700;">${incomePercent}%</span>
                  </div>
                  <div style="display: flex; justify-content: space-between; align-items: center; font-size: 10px;">
                    <span style="display: flex; align-items: center; gap: 4px;"><span style="width: 6px; height: 6px; border-radius: 50%; background: #ef4444; display: inline-block;"></span>Keluar</span>
                    <span style="font-weight: 700;">${expensePercent}%</span>
                  </div>
                </div>
              </div>
            </div>

            <div class="chart-card" style="display: flex; flex-direction: column; justify-content: center;">
              <h4 style="margin: 0 0 10px 0; font-size: 10px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.05em; color: #6b7280;">Kategori Pengeluaran Terbesar</h4>
              <div style="display: flex; flex-direction: column;">
                ${topCategoriesUI}
              </div>
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th style="width: 50px; border-top-left-radius: 8px;">No</th>
                <th style="width: 120px;">Tanggal</th>
                <th style="width: 120px;">Tipe</th>
                <th style="width: 120px;">Kategori</th>
                <th>Keterangan</th>
                <th style="text-align: right; width: 150px; border-top-right-radius: 8px;">Jumlah</th>
              </tr>
            </thead>
            <tbody>
              ${rows || '<tr><td colspan="6" style="text-align: center; padding: 40px; color: #9ca3af; font-size: 13px;">Belum ada data transaksi</td></tr>'}
            </tbody>
          </table>

          <div class="print-btn-bar">
            <p style="margin: 0 0 12px 0; font-size: 13px; color: #1f2937; font-weight: 700;">Laporan PDF Siap Dicetak & Disimpan</p>
            <button class="btn-accent" onclick="window.print()">Cetak / Simpan PDF</button>
            <button class="btn-secondary" onclick="window.close()">Tutup Halaman</button>
          </div>

          <script>
            window.onload = function() {
              setTimeout(function() {
                window.print();
              }, 300);
            }
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: `Halo **${displayUserName}**! 👋\n\nSaya **FinBOT**, asisten keuangan pribadi cerdas Anda di **AturDuit**.\n\nSaya siap membantu Anda:\n- Menganalisis pola pengeluaran & pemasukan.\n- Memberikan tips praktis berhemat untuk mencapai target impian Anda.\n- Membuat rencana anggaran bulanan yang bijak.\n\nAda yang bisa saya bantu atau analisis hari ini?`
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Prompt starter suggestion chips
  const promptStarters = [
    "Bagaimana kondisi keuangan saya saat ini?",
    "Berikan 3 tips praktis menghemat uang hari ini",
    "Bantu anggarkan uang bulanan saya",
    "Bagaimana progres tabungan & impian saya?"
  ];

  const buildContext = () => {
    const totalIncome = transactions.filter(t => t.type === 'income').reduce((sum, t) => sum + (t.amount || 0), 0);
    const totalExpense = transactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + (t.amount || 0), 0);
    const totalGoalDeposits = transactions.filter(t => t.type === 'goal').reduce((sum, t) => sum + (t.amount || 0), 0);
    const balance = totalIncome - totalExpense - totalGoalDeposits;

    const goalsSummary = (profile?.savingsGoals || []).map((g: any) => {
      const progress = Math.min((g.currentAmount / g.targetAmount) * 100, 100);
      return `- **${g.name}**: Terkumpul ${currency} ${new Intl.NumberFormat('id-ID').format(g.currentAmount)} dari target ${currency} ${new Intl.NumberFormat('id-ID').format(g.targetAmount)} (${progress.toFixed(0)}% progres, tenggat: ${g.deadline || 'Tidak ada'})`;
    }).join('\n');

    const recentTxns = transactions.slice(0, 15).map((t: any) => {
      const typeLabel = t.type === 'income' ? 'Pemasukan' : t.type === 'expense' ? 'Pengeluaran' : 'Tabungan Goal';
      return `- **${t.date}**: ${typeLabel} sebesar ${currency} ${new Intl.NumberFormat('id-ID').format(t.amount)} (${t.category} - ${t.description || 'Tidak ada keterangan'})`;
    }).join('\n');

    return `Nama Pengguna: ${displayUserName}
Mata Uang Default: ${currency}
Total Pemasukan: ${currency} ${new Intl.NumberFormat('id-ID').format(totalIncome)}
Total Pengeluaran: ${currency} ${new Intl.NumberFormat('id-ID').format(totalExpense)}
Tabungan Masuk ke Impian: ${currency} ${new Intl.NumberFormat('id-ID').format(totalGoalDeposits)}
Sisa Saldo Kas: ${currency} ${new Intl.NumberFormat('id-ID').format(balance)}

Target Impian & Tabungan Pengguna:
${goalsSummary || 'Belum ada target impian.'}

15 Transaksi Terakhir Pengguna:
${recentTxns || 'Belum ada riwayat transaksi.'}`;
  };

  const handleSend = async (textToSend: string) => {
    if (!textToSend.trim() || loading) return;

    setError(null);
    const userMessage: Message = { role: 'user', content: textToSend };
    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    setInput('');
    setLoading(true);

    try {
      const financeContext = buildContext();
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          messages: updatedMessages,
          context: financeContext
        })
      });

      if (!response.ok) {
        throw new Error('Gagal terhubung dengan server FinBOT.');
      }

      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }

      setMessages(prev => [...prev, { role: 'assistant', content: data.reply }]);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Maaf, terjadi kesalahan koneksi server.');
    } finally {
      setLoading(false);
    }
  };

  const handleClearChat = () => {
    if (confirm('Apakah Anda ingin menghapus obrolan ini?')) {
      setMessages([
        {
          role: 'assistant',
          content: `Halo **${displayUserName}**! 👋\n\nObrolan telah dibersihkan. Ada analisa keuangan atau tips hemat yang bisa saya bantu hari ini?`
        }
      ]);
      setError(null);
    }
  };

  return (
    <div className="bg-white rounded-[40px] shadow-2xl border border-gray-100 overflow-hidden flex flex-col h-[650px] animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Top Header Card */}
      <div className="bg-gradient-to-r from-blue-600 to-black p-6 flex items-center justify-between shadow-md relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,255,255,0.1),transparent_50%)] pointer-events-none" />
        <div className="flex items-center gap-4 relative z-10">
          <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-white shadow-inner animate-pulse">
            <Bot size={26} strokeWidth={2.5} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-white font-black text-lg tracking-tight leading-none">FinBOT Advisor</h3>
              <span className="bg-white/10 text-white border border-white/20 text-[9px] font-black uppercase px-2 py-0.5 rounded-full tracking-widest leading-none">AI Smart</span>
            </div>
            <p className="text-white/60 text-xs font-medium mt-1">Konsultan Keuangan Pribadi AturDuit Anda</p>
          </div>
        </div>

        <button
          onClick={handleClearChat}
          title="Bersihkan Obrolan"
          className="p-3 text-white/60 hover:text-white hover:bg-white/10 rounded-2xl transition-all relative z-10"
        >
          <Trash2 size={20} />
        </button>
      </div>

      {/* Info Banner */}
      <div className="bg-blue-50/50 border-b border-blue-100/50 px-6 py-2.5 flex items-center gap-2 text-blue-700 text-[10px] font-black uppercase tracking-wider">
        <ShieldCheck size={14} className="text-blue-600" />
        <span>FinBOT menganalisis data transaksi & impian Anda secara privat & aman</span>
      </div>

      {/* Chat Thread */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50/50">
        {messages.map((msg, index) => {
          const hasXLSX = msg.content.includes('[DOWNLOAD_XLSX]');
          const hasPDF = msg.content.includes('[DOWNLOAD_PDF]');
          const cleanedText = msg.content
            .replace(/\[DOWNLOAD_XLSX\]/g, '')
            .replace(/\[DOWNLOAD_PDF\]/g, '')
            .trim();

          return (
            <div
              key={index}
              className={`flex items-start gap-3.5 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
            >
              {/* Avatar / Icon */}
              <div
                className={`w-9 h-9 rounded-2xl flex items-center justify-center shadow-md shrink-0 border transition-all ${
                  msg.role === 'user'
                    ? 'bg-black text-white border-black'
                    : 'bg-gradient-to-tr from-blue-600 to-black text-white border-blue-500/20'
                }`}
              >
                {msg.role === 'user' ? (
                  <span className="text-xs font-black uppercase">{displayUserName.charAt(0)}</span>
                ) : (
                  <Sparkles size={16} />
                )}
              </div>

              {/* Bubble */}
              <div
                className={`max-w-[80%] p-5 rounded-[28px] shadow-sm transition-all text-sm leading-relaxed ${
                  msg.role === 'user'
                    ? 'bg-black text-white rounded-tr-sm font-medium'
                    : 'bg-white text-gray-800 border border-gray-100 rounded-tl-sm'
                }`}
              >
                <div className="markdown-body prose max-w-none text-xs sm:text-sm font-normal">
                  <Markdown>{cleanedText}</Markdown>
                </div>

                {(hasXLSX || hasPDF) && (
                  <div className="mt-4 pt-4 border-t border-gray-100 flex flex-wrap gap-2.5">
                    {hasXLSX && (
                      <button
                        onClick={exportAllXLSX}
                        className="flex items-center gap-2 px-4 py-2.5 bg-green-50 hover:bg-green-100 text-[#10b981] hover:text-[#059669] rounded-2xl font-black text-[10px] uppercase tracking-wider transition-all shadow-sm cursor-pointer border border-green-100"
                      >
                        <FileSpreadsheet size={14} />
                        Unduh Excel (.xlsx)
                      </button>
                    )}
                    {hasPDF && (
                      <button
                        onClick={exportAllPDF}
                        className="flex items-center gap-2 px-4 py-2.5 bg-red-50 hover:bg-red-100 text-[#ef4444] hover:text-[#dc2626] rounded-2xl font-black text-[10px] uppercase tracking-wider transition-all shadow-sm cursor-pointer border border-red-100"
                      >
                        <FileText size={14} />
                        Unduh Laporan PDF
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {/* Loading Bubble */}
        {loading && (
          <div className="flex items-start gap-4">
            <div className="w-9 h-9 rounded-2xl flex items-center justify-center bg-gradient-to-tr from-blue-600 to-black text-white border border-blue-500/10 shadow-md">
              <Sparkles size={16} className="animate-spin" />
            </div>
            <div className="bg-white p-5 rounded-[28px] border border-gray-100 rounded-tl-sm shadow-sm flex items-center gap-3">
              <div className="flex gap-1">
                <span className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
              <span className="text-xs font-black text-gray-400 uppercase tracking-widest">FinBOT sedang menganalisis...</span>
            </div>
          </div>
        )}

        {/* Error Alert */}
        {error && (
          <div className="p-4 bg-red-50 text-red-600 rounded-[24px] border border-red-100 flex items-center gap-3 animate-pulse">
            <Info size={18} />
            <p className="text-xs font-bold leading-normal">{error}</p>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggestion Starter Chips */}
      {messages.length === 1 && !loading && (
        <div className="px-6 py-3 border-t border-gray-100 bg-white">
          <p className="text-[9px] font-black text-gray-400 uppercase tracking-wider mb-2 ml-1">Mulai obrolan dengan cepat:</p>
          <div className="flex flex-wrap gap-2">
            {promptStarters.map((starter, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSend(starter)}
                className="bg-gray-100 hover:bg-blue-50 text-gray-600 hover:text-blue-700 font-bold text-[10px] uppercase tracking-wider px-4 py-2.5 rounded-full transition-all text-left border border-gray-200/50 hover:border-blue-300 shadow-sm hover:scale-102"
              >
                {starter}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Message Input Area */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSend(input);
        }}
        className="p-5 border-t border-gray-100 bg-white flex gap-3 items-center"
      >
        <input
          required
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          disabled={loading}
          placeholder="Tanyakan pola pengeluaran atau tips hemat..."
          className="flex-1 bg-gray-50 text-gray-800 p-4 rounded-2xl outline-none text-sm placeholder:text-gray-400 focus:bg-gray-100 transition-all border border-transparent focus:border-gray-200"
        />
        <button
          type="submit"
          disabled={loading || !input.trim()}
          className="w-12 h-12 rounded-2xl bg-black text-white flex items-center justify-center shadow-lg shadow-black/10 hover:bg-blue-600 hover:scale-105 active:scale-95 disabled:bg-gray-200 disabled:text-gray-400 disabled:scale-100 disabled:shadow-none transition-all duration-300"
        >
          <Send size={18} />
        </button>
      </form>
    </div>
  );
}
