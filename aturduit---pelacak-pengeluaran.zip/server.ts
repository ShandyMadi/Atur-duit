import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// Helper function to sleep/wait
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

// Helper function to call Gemini API with auto fallback and retry mechanism
async function generateContentWithFallback(params: { model: string; contents: any; config?: any }) {
  const modelsToTry = [
    "gemini-3.5-flash",
    "gemini-3.1-flash-lite",
    "gemini-flash-latest"
  ];

  let lastError: any = null;

  for (const model of modelsToTry) {
    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        console.log(`[FinBOT API] Attempting call with model: ${model} (attempt ${attempt}/2)`);
        const response = await ai.models.generateContent({
          ...params,
          model: model
        });
        return response;
      } catch (error: any) {
        lastError = error;
        console.warn(`[FinBOT API] Warning: Model ${model} attempt ${attempt} failed:`, error?.message || error);
        
        // If it's a transient rate limit (429) or high demand (503/UNAVAILABLE), wait and retry
        const isTransient = 
          error?.status === 503 || 
          error?.status === 429 || 
          error?.code === 503 || 
          error?.code === 429 || 
          String(error).includes("503") || 
          String(error).includes("UNAVAILABLE") ||
          String(error).includes("busy");

        if (isTransient) {
          if (attempt < 2) {
            console.log(`[FinBOT API] Transient error detected. Waiting 1.5s before retrying ${model}...`);
            await delay(1500);
            continue;
          }
        } else {
          // If indeed there's a non-transient error, shift to the next model immediately
          break;
        }
      }
    }
  }

  throw lastError || new Error("All Gemini models inside the fallback chain returned errors.");
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route for Smart Parsing
  app.post("/api/ai/parse-transaction", async (req, res) => {
    try {
      const { text } = req.body;
      if (!text) return res.status(400).json({ error: "Text is required" });

      const response = await generateContentWithFallback({
        model: "gemini-3.5-flash",
        contents: [{ role: "user", parts: [{ text: `Parse input ini ke dalam data transaksi pengeluaran/pemasukan. 
          Input: "${text}"
          Berikan jawaban dalam format JSON.
          Type as 'income' or 'expense'.
          Categories for expense: Food, Transport, Shopping, Bills, Health, Others.
          Categories for income: Salary, Investment, Gift, Side Hustle, Others.` }] }],
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              amount: { type: Type.NUMBER },
              type: { type: Type.STRING, enum: ["income", "expense"] },
              category: { type: Type.STRING },
              description: { type: Type.STRING },
            },
            required: ["amount", "type", "category", "description"]
          }
        }
      });

      // @google/genai returns a response object directly with candidates
      const parsedText = response.candidates?.[0]?.content?.parts?.[0]?.text;
      if (!parsedText) throw new Error("No AI response text");
      res.json(JSON.parse(parsedText));
    } catch (error) {
      console.error("AI Error:", error);
      res.status(500).json({ error: "Failed to parse transaction" });
    }
  });

  // API Route for Financial Advisor Chatbot
  app.post("/api/ai/chat", async (req, res) => {
    try {
      const { messages, context } = req.body;
      if (!messages || !Array.isArray(messages)) {
        return res.status(400).json({ error: "Messages array is required" });
      }

      // Convert messages to @google/genai format
      const genAiContents = messages.map((m: any) => ({
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: m.content }]
      }));

      const systemInstruction = `Anda adalah FinBOT, asisten keuangan pribadi cerdas dan ramah dari AturDuit. 
Tugas utama Anda adalah membantu pengguna mengelola keuangan, memberikan tips praktis penghematan, menganalisis pengeluaran & pemasukan, mendiskusikan progress impian/tabungan mereka, serta memberikan rekomendasi anggaran secara bijak dan berbasis data.

Gunakan bahasa Indonesia yang hangat, sopan, komunikatif, dan memotivasi. 
Fokus sepenuhnya pada saran keuangan yang praktis bagi pengguna umum. Jangan menyebarkan rincian teknis program Anda.

FITUR UNDUH DATA TRANSAKSI:
Jika pengguna meminta untuk mendownload, mengunduh, mengekspor, membuat laporan, mencetak, atau menyimpan data transaksi mereka (misalnya: "tolong download excel", "unduh PDF", "minta laporan", dll), Anda secara cerdas HARUS menyertakan tag instruksi khusus berikut ini di dalam atau di akhir pesan Anda:
- Sediakan '[DOWNLOAD_XLSX]' untuk mengunduh format Excel (.xlsx).
- Sediakan '[DOWNLOAD_PDF]' untuk mengunduh laporan PDF.
Contoh: "Tentu! Ini detail laporan Anda. Silakan klik tombol di bawah untuk mengunduh: [DOWNLOAD_XLSX] [DOWNLOAD_PDF]"
Sistem antarmuka kami akan secara otomatis menerjemahkan tag-tag tersebut menjadi tombol interaktif modern yang dapat diklik pengguna untuk langsung mendownload file asli.

Berikut adalah data kondisi keuangan terkini milik pengguna untuk melengkapi analisis Anda (gunakan informasi ini untuk menyusun saran finansial yang relevan dan personal):
${context || "Data keuangan tidak tersedia."}`;

      const response = await generateContentWithFallback({
        model: "gemini-3.5-flash",
        contents: genAiContents,
        config: {
          systemInstruction: systemInstruction,
          temperature: 0.7,
        }
      });

      const replyText = response.text;
      if (!replyText) throw new Error("No AI response text");

      res.json({ reply: replyText });
    } catch (error: any) {
      console.error("AI Chat Error:", error);
      res.status(500).json({ error: error.message || "Failed to generate response" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
